

module.exports = {
	dev: false,
	window:{
		width: 1200,
		height: 800
	}
};