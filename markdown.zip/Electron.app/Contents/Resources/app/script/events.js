/**
 * Created by synder on 16/6/15.
 */


module.exports = {
    MENUS_EVENT : {
        NEW_FILE   : 'new-file',
        OPEN_FILE  : 'open-file',
        SAVE_FILE  : 'save-file',
        EXPORT_HTML_FILE : 'export-html-file',
        EXPORT_PDF_FILE : 'export-pdf-file',
        SPLIT_VIEW : 'split-view',
        LOCK_VIEW  : 'lock-view',
        PRE_VIEW   : 'pre-view'
    }
};